
<?php
echo "<ul><li>Without flowing wine,</li>";
echo "<br>";
echo "<li>How to enjoy lovely</li>";
echo "<br>";
echo "<li>Cheery blossoms.</li></ul>";
?>