<?php

$petType = $_GET['species'];
$noiseMade = $_GET['noise'];
echo "<p>Your {$petType} goes {$noiseMade}-{$noiseMade}.</p>";

?>