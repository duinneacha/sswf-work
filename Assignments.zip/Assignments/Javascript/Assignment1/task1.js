
let birthYear = 1970;
let futureYear = 2048;

let ageThen = futureYear - birthYear;

console.log(`I will be wither ${ageThen - 1} or ${ageThen} in ${futureYear}`);

