

const tellFortune = (numChildren, partnersName, geoLocation, jobTitle) => {

  console.log(`
  You will have ${numChildren} children.
  Your Partners name will be ${partnersName}.
  You will live in ${geoLocation}.
  Your job title will be ${jobTitle}.`)

};


tellFortune(4, "Michelle", "Cork", "Astronaut");
tellFortune(1, "Sandra", "Southampton", "Software Engineer");
tellFortune(7, "Aileen", "Wicklow", "Mechanic");