

const calculateDogAge = (puppyAge, conversionRate) => {

  let dogYears = puppyAge * conversionRate;

  console.log(`Your doggie is ${dogYears} years old in dog years!`);

};


calculateDogAge(5, 7);
calculateDogAge(3, 4.5);
calculateDogAge(15, 7);

